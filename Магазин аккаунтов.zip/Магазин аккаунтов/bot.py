import telebot
import const

from telebot import types
from telebot.types import LabeledPrice

bot = telebot.TeleBot(const.TOKEN)

prices = [LabeledPrice(label='Аккаунт Gmail', amount=6704210)] # 67042.10

# def gmail():
#     gmail1 = types.InlineKeyboardMarkup(row_width=1)
#     but_1 = types.InlineKeyboardButton(text='Авторег 20р/шт', url='https://www.oplata.info/asp2/pay_wm.asp?id_d=2360028&id_po=0&cart_uid=&ai=0&curr=WMR&failpage=https%3A%2F%2Fwmcentre%2Enet%2Fitem%2F5515-mmr-dota-2-bez-privyazki-telefona-2360028&lang=ru-RU&nocash=885918&_ow=&_ids_shop=')
#     but_2 = types.InlineKeyboardButton(text='Авторег с отлегой 6 месяцев 100р/шт', url='https://www.oplata.info/asp2/pay_wm.asp?id_d=2360028&id_po=0&cart_uid=&ai=0&curr=WMR&failpage=https%3A%2F%2Fwmcentre%2Enet%2Fitem%2F5515-mmr-dota-2-bez-privyazki-telefona-2360028&lang=ru-RU&nocash=885918&_ow=&_ids_shop=')
#     but_3 = types.InlineKeyboardButton(text='Авторег с отлегой 12 месяцев 200р/шт', url='https://www.oplata.info/asp2/pay_wm.asp?id_d=2360028&id_po=0&cart_uid=&ai=0&curr=WMR&failpage=https%3A%2F%2Fwmcentre%2Enet%2Fitem%2F5515-mmr-dota-2-bez-privyazki-telefona-2360028&lang=ru-RU&nocash=885918&_ow=&_ids_shop=')
#     gmail1.add(but_1, but_2, but_3)
#     return gmail1

def insta():
    instagram = types.InlineKeyboardMarkup()
    but_1 = types.InlineKeyboardButton(text='Авторег 1р/шт', url='https://www.oplata.info/asp2/pay_wm.asp?id_d=2360028&id_po=0&cart_uid=&ai=0&curr=WMR&failpage=https%3A%2F%2Fwmcentre%2Enet%2Fitem%2F5515-mmr-dota-2-bez-privyazki-telefona-2360028&lang=ru-RU&nocash=885918&_ow=&_ids_shop=')
    but_2 = types.InlineKeyboardButton(text='Cтарые 25р/шт', url='https://www.oplata.info/asp2/pay_wm.asp?id_d=2360028&id_po=0&cart_uid=&ai=0&curr=WMR&failpage=https%3A%2F%2Fwmcentre%2Enet%2Fitem%2F5515-mmr-dota-2-bez-privyazki-telefona-2360028&lang=ru-RU&nocash=885918&_ow=&_ids_shop=')
    but_3 = types.InlineKeyboardButton(text='Брут 10р/шт', url='https://www.oplata.info/asp2/pay_wm.asp?id_d=2360028&id_po=0&cart_uid=&ai=0&curr=WMR&failpage=https%3A%2F%2Fwmcentre%2Enet%2Fitem%2F5515-mmr-dota-2-bez-privyazki-telefona-2360028&lang=ru-RU&nocash=885918&_ow=&_ids_shop=')
    but_4 = types.InlineKeyboardButton(text='Раскрученные 700р/шт', url='https://www.oplata.info/asp2/pay_wm.asp?id_d=2360028&id_po=0&cart_uid=&ai=0&curr=WMR&failpage=https%3A%2F%2Fwmcentre%2Enet%2Fitem%2F5515-mmr-dota-2-bez-privyazki-telefona-2360028&lang=ru-RU&nocash=885918&_ow=&_ids_shop=')
    instagram.add(but_1, but_2)
    instagram.add(but_3, but_4)
    return instagram

@bot.message_handler(commands=['start'])
def startpg(message):
    startmenu = types.ReplyKeyboardMarkup(True, False)
    startmenu.row('Аккаунты Gmail', 'Аккаунты Intagram')
    startmenu.row('Аккаунты VK', 'Аккаунты MAIL.RU')
    startmenu.row('Аккаунты Facebook', 'Аккаунты Yandex')
    bot.send_message(message.chat.id, 'Привет {name}!\nЯ бот, который продает Аккаунты!\nВыбирай какие тебе аккаунты нужны:'.format(name=message.chat.first_name), reply_markup=startmenu)

@bot.message_handler(content_types=['text'])
def osnov(message):
    if message.text == 'Аккаунты Gmail':
        bot.send_invoice(message.chat.id, title='Аккаунт Gmail',
                         description='Новорег аккаунт Gmail',
                         currency='rub',
                         #photo_url='http://res.cloudinary.com/muzicius/image/upload/v1493211949/foodservice-icecake/srrtvbiwv1wgfd8c8ppj.jpg',
                         is_flexible=False,  # True If you need to set up Shipping Fee
                         prices=prices,
                         start_parameter='account',
                         invoice_payload='Account za 10 rub',
                         provider_token="410182388:LIVE:db16118c-ce3f-42ad-9768-9b5763048387")
    elif message.text == 'Аккаунты Intagram':
        bot.send_message(message.chat.id, 'Нажмите на нужный аккаунт из списка:\n(Ссылка для примера)', reply_markup=insta())
    elif message.text == 'Аккаунты VK':
        bot.send_message(message.chat.id, 'Нажмите на нужный аккаунт из списка:\n(Ссылка для примера)', reply_markup=insta())
    elif message.text == 'Аккаунты Facebook':
        bot.send_message(message.chat.id, 'Нажмите на нужный аккаунт из списка:\n(Ссылка для примера)', reply_markup=insta())
    elif message.text == 'Аккаунты MAIL.RU':
        bot.send_message(message.chat.id, 'Нажмите на нужный аккаунт из списка:\n(Ссылка для примера)', reply_markup=insta())
    elif message.text == 'Аккаунты Yandex':
        bot.send_message(message.chat.id, 'Нажмите на нужный аккаунт из списка:\n(Ссылка для примера)', reply_markup=insta())







bot.polling()